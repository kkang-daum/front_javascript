"use strict";

var array = [];

for (var i = 0; i < 10; i++) {
  array[i] = function () {
    return i;
  };
}

for (var j = 0; j < array.length; j++) {
  console.log(array[j]());
}